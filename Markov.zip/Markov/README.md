#Markov words generator

Basic sentence generator using markov chains. Put data you want to analyse in data/

My first Java program. Be gentle :)
