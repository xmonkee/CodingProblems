package com.xmonkee;

/**
 * Created by mandu on 07/12/14.
 */
public class WordCountPair {
    public int count;
    public final String word;

    public WordCountPair(String word, int count) {
        this.count = count;
        this.word = word;
    }
}
